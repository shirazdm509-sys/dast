"""
security.py - ماژول امنیتی پیشرفته
- Rate limiting
- Input sanitization
- SQL injection prevention
- XSS prevention
- Brute force protection
"""

import re
import time
import hashlib
import hmac
from collections import defaultdict
from typing import Optional
from fastapi import HTTPException, Request

# ── Rate Limiting ────────────────────────────────────────────
_requests   = defaultdict(list)
_login_fail = defaultdict(list)
_blocked    = {}  # ip → unblock_time

RATE_LIMITS = {
    "general":   (60, 60),    # 60 req / 60s
    "ask":       (20, 60),    # 20 ask / 60s
    "login":     (5,  300),   # 5 tries / 5min
}

def check_rate(ip: str, endpoint: str = "general"):
    now = time.time()

    # بررسی block
    if ip in _blocked:
        if now < _blocked[ip]:
            wait = int(_blocked[ip] - now)
            raise HTTPException(429, f"IP مسدود شده. {wait} ثانیه صبر کنید.")
        else:
            del _blocked[ip]

    limit, window = RATE_LIMITS.get(endpoint, RATE_LIMITS["general"])
    key = f"{ip}:{endpoint}"
    _requests[key] = [t for t in _requests[key] if now - t < window]

    if len(_requests[key]) >= limit:
        # block برای 10 دقیقه بعد از ۳ بار مازاد
        if len(_requests[key]) >= limit * 2:
            _blocked[ip] = now + 600
        raise HTTPException(429, f"درخواست‌ها بیش از حد مجاز. کمی صبر کنید.")

    _requests[key].append(now)

def check_login(ip: str, success: bool = False):
    now = time.time()
    if success:
        _login_fail[ip] = []
        return

    _login_fail[ip] = [t for t in _login_fail[ip] if now - t < 300]
    if len(_login_fail[ip]) >= 5:
        _blocked[ip] = now + 900  # 15 دقیقه block
        raise HTTPException(429, "حساب موقتاً مسدود شد. ۱۵ دقیقه صبر کنید.")
    _login_fail[ip].append(now)

# ── Input Sanitization ────────────────────────────────────────
DANGEROUS_PATTERNS = [
    r'<script[^>]*>.*?</script>',
    r'javascript\s*:',
    r'on\w+\s*=',
    r'<iframe',
    r'document\.cookie',
    r'eval\s*\(',
    r'window\.location',
    r'\.\./\.\.',           # path traversal
    r'%2e%2e',              # encoded path traversal
    r'union\s+select',      # SQL injection
    r'drop\s+table',
    r'insert\s+into',
    r';\s*--',
]

def sanitize_input(text: str, max_len: int = 1000) -> str:
    if not text:
        return ""

    # محدودیت طول
    text = text[:max_len]

    # حذف null bytes
    text = text.replace('\x00', '')

    # بررسی patterns خطرناک
    text_lower = text.lower()
    for pattern in DANGEROUS_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE | re.DOTALL):
            raise HTTPException(400, "ورودی نامعتبر است")

    return text.strip()

def sanitize_username(username: str) -> str:
    username = username.strip()[:50]
    if not re.match(r'^[a-zA-Z0-9_\-\.]+$', username):
        raise HTTPException(400, "نام کاربری فقط می‌تواند شامل حروف لاتین، اعداد و _-. باشد")
    if len(username) < 3:
        raise HTTPException(400, "نام کاربری باید حداقل ۳ کاراکتر باشد")
    return username

def sanitize_password(password: str) -> str:
    if len(password) < 4:
        raise HTTPException(400, "رمز عبور باید حداقل ۴ کاراکتر باشد")
    if len(password) > 128:
        raise HTTPException(400, "رمز عبور خیلی طولانی است")
    return password

# ── Hash ──────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def verify_password(plain: str, hashed: str) -> bool:
    return hmac.compare_digest(hash_password(plain), hashed)

# ── Security Headers ──────────────────────────────────────────
SECURITY_HEADERS = {
    "X-Content-Type-Options":    "nosniff",
    "X-Frame-Options":           "DENY",
    "X-XSS-Protection":          "1; mode=block",
    "Referrer-Policy":           "strict-origin-when-cross-origin",
    "Permissions-Policy":        "camera=(), microphone=(), geolocation=()",
    "Content-Security-Policy":   "default-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;",
}

def get_client_ip(request: Request) -> str:
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "0.0.0.0"
