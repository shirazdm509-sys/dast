"""
retriever.py - سیستم جستجو و پاسخ‌دهی رساله آیت‌الله دستغیب
ویژگی‌ها:
- درک سوالات عامیانه فارسی (حکم سیگار در رمضون چیه؟)
- جستجوی مستقیم شماره مسئله
- جستجوی semantic با چند query
- reranking با LLM
- ارائه رفرنس کامل (شماره مسئله + بخش)
"""

import os
import re
import json
import asyncio
from typing import List, Dict, Optional, AsyncGenerator
from openai import OpenAI, AsyncOpenAI
from ingestion import get_collection, get_collection_stats, get_embeddings

API_KEY = "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"
client = OpenAI(api_key=API_KEY)
async_client = AsyncOpenAI(api_key=API_KEY)

SIMILARITY_THRESHOLD = 0.13

# ── نقشه section به شماره مسئله (از تحلیل فایل واقعی) ─────────
SECTION_PROBLEM_MAP = {
    "احکام تقلید": (1, 15),
    "احکام طهارت": (16, 83),
    "نجاسات": (84, 149),
    "مطهرات": (150, 236),
    "وضو": (237, 347),
    "غسل": (348, 530),
    "احکام میت": (531, 644),
    "تیمم": (645, 723),
    "احکام نماز": (724, 1620),
    "احکام روزه": (1621, 1818),
    "احکام خمس": (1819, 1921),
    "احکام زکات": (1922, 2104),
    "احکام حج": (2105, 2120),
    "احکام خرید و فروش": (2121, 2214),
    "احکام نکاح": (2452, 2554),
    "احکام طلاق": (2589, 2637),
    "احکام خوردنیها": (2717, 2732),
}

# ── Small Talk ───────────────────────────────────────────────
SMALL_TALK = {
    "سلام": "سلام! خوش آمدید 🌿\nمن دستیار رساله آیت‌الله سید علی محمد دستغیب هستم.\nسوال فقهی خود را بپرسید.",
    "خوبی": "ممنون! در خدمتم. چه سوالی دارید؟",
    "چطوری": "خوبم! آماده پاسخ به سوالات فقهی شما هستم.",
    "ممنون": "خواهش می‌کنم! اگر سوال دیگری دارید بفرمایید.",
    "مرسی": "خواهش می‌کنم!",
    "ممنونم": "خواهش می‌کنم! در خدمتم.",
    "خداحافظ": "خداحافظ! موفق باشید. 🌿",
    "بای": "خداحافظ!",
    "hello": "سلام! چه سوالی از رساله دارید؟",
    "hi": "سلام!",
    "کی هستی": "من دستیار رساله فقهی آیت‌الله سید علی محمد دستغیب هستم و سوالات فقهی را از رساله ایشان پاسخ می‌دهم.",
    "چی میدونی": "رساله کامل آیت‌الله دستغیب را می‌دانم: از احکام طهارت، نماز، روزه، خمس، زکات تا احکام معاملات، ازدواج، طلاق و امر به معروف.",
    "چه بلدی": "رساله کامل آیت‌الله دستغیب را می‌دانم. هر سوال فقهی که دارید بپرسید.",
}


def is_small_talk(q: str) -> Optional[str]:
    q_lower = q.strip().lower()
    if len(q_lower) > 70:
        return None
    for k, v in SMALL_TALK.items():
        if k in q_lower:
            return v
    return None


# ── نرمال‌سازی سوالات عامیانه فارسی ─────────────────────────
# این دیکشنری مشکل "حکم سیگار در رمضون چیه" را حل می‌کند
COLLOQUIAL_FIXES = {
    # تلفظ عامیانه ← رسمی
    "رمضون": "رمضان",
    "ماه رمضون": "ماه رمضان",
    "نمازخوندن": "نماز خواندن",
    "نماز خوندن": "نماز خواندن",
    "وضوگرفتن": "وضو گرفتن",
    "وضو گرفتن": "وضو گرفتن",
    "دستشویی": "تخلی",
    "توالت": "تخلی",
    "عروسی": "ازدواج نکاح",
    # کلمات عامیانه ← فقهی
    "سیگار کشیدن": "سیگار دود دخان تنباکو",
    "سیگار کشیدن در": "دود سیگار تنباکو در",
    "قلیان کشیدن": "قلیان دود دخان",
    "ناپاک": "نجس",
    "پاک کردن": "تطهیر",
    "گناهه": "حرام است",
    "گناه داره": "حرام است",
    "چی میشه": "حکم چیست",
    "چیه حکمش": "حکم چیست",
    "حکمش چیه": "حکم چیست",
    "مشکلی داره": "جایز است یا خیر",
    "میشه": "جایز است",
    "نمیشه": "جایز نیست",
    "میتونم": "می‌توانم",
    "میتوانم": "می‌توانم",
    "چیه": "چیست",
    "کجاست": "کجاست",
    "باطله": "باطل است",
    "صحیحه": "صحیح است",
}

# مترادف‌های فقهی - اضافه به query برای جستجوی بهتر
FIQH_EXPAND = {
    "سیگار": "دود سیگار دخان تنباکو",
    "قلیان": "قلیان دود دخان",
    "روزه": "روزه صوم صائم",
    "رمضان": "رمضان ماه رمضان",
    "نماز": "نماز صلات",
    "وضو": "وضو طهارت",
    "غسل": "غسل جنابت",
    "نجس": "نجس نجاست",
    "پاک": "طاهر طهارت",
    "خون": "خون دم",
    "نفاس": "خون نفاس",
    "حیض": "حیض خون حیض",
    "جنب": "جنابت جنب",
    "ازدواج": "نکاح ازدواج عقد",
    "طلاق": "طلاق فسخ",
    "خرید": "بیع معامله خرید و فروش",
    "ربا": "ربا بهره سود",
    "خمس": "خمس",
    "زکات": "زکات",
    "حج": "حج",
}


def normalize_colloquial(q: str) -> str:
    """تبدیل سوال عامیانه به رسمی"""
    result = q
    for coll, formal in COLLOQUIAL_FIXES.items():
        result = result.replace(coll, formal)
    result = re.sub(r'[؟?!]+', '؟', result)
    return result.strip()


def expand_query(q: str) -> str:
    """اضافه کردن مترادف‌های فقهی به query"""
    expansions = []
    for word, synonyms in FIQH_EXPAND.items():
        if word in q:
            expansions.append(synonyms)
    if expansions:
        return q + " " + " ".join(expansions)
    return q


# ── تشخیص شماره مسئله ────────────────────────────────────────
def extract_problem_number(q: str) -> Optional[int]:
    patterns = [
        r'(?:مسئله|مسأله|مساله|سوال)\s*(\d+)',
        r'(\d+)\s*(?:ام|مین)?\s*(?:مسئله|مسأله)',
        r'^(\d+)\s*[-\.\)]\s',
    ]
    for p in patterns:
        m = re.search(p, q, re.IGNORECASE)
        if m:
            return int(m.group(1))
    return None


# ── تحلیل سوال با GPT-4o ─────────────────────────────────────
def analyze_question(original: str, normalized: str) -> Dict:
    """
    تحلیل هوشمند سوال - درک عامیانه و تولید queries متنوع.
    مثال: "حکم سیگار در رمضون چیه؟"
    → formal: "حکم کشیدن سیگار و دود برای روزه‌دار در ماه رمضان"
    → keywords: ["دود", "سیگار", "روزه", "رمضان", "مبطلات"]
    → section: "احکام روزه"
    """
    prompt = f"""تو متخصص فقه اسلامی و رساله‌های عملیه هستی.
سوال فارسی (ممکن است عامیانه باشد) درباره رساله فقهی دریافت کن و JSON برگردان:

{{
  "keywords_fa": ["کلمات کلیدی فقهی فارسی - حداکثر 8 تا"],
  "keywords_ar": ["مترادف عربی فقهی"],
  "section": "بخش رساله که جواب احتمالاً در آن است (مثل: احکام روزه)",
  "formal_query": "سوال به فارسی فقهی رسمی و کامل",
  "keyword_query": "فقط کلمات کلیدی فقهی بدون فعل و کمک‌فعل",
  "expanded_query": "سوال با توضیحات و مترادف‌های فقهی بیشتر",
  "is_about_prohibition": true/false
}}

مهم: 
- "سیگار در رمضون" → formal: "حکم دود سیگار و دخان برای روزه‌دار در ماه رمضان"
- "میشه نماز خوند" → formal: "آیا نماز خواندن در این شرایط جایز است"
- کلمات عامیانه را به اصطلاح فقهی تبدیل کن
- keywords_ar: معادل عربی اگر در متون فقهی رایج است

سوال اصلی: {original}
سوال نرمال‌شده: {normalized}

فقط JSON بده."""

    try:
        r = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.0,
            max_tokens=400,
            response_format={"type": "json_object"}
        )
        return json.loads(r.choices[0].message.content)
    except:
        return {
            "keywords_fa": [],
            "keywords_ar": [],
            "section": "",
            "formal_query": normalized,
            "keyword_query": normalized,
            "expanded_query": normalized,
            "is_about_prohibition": False
        }


# ── جستجوی مستقیم شماره مسئله ───────────────────────────────
def search_by_number(num: int) -> List[Dict]:
    try:
        col = get_collection()
        res = col.get(where={"problem_number": num}, include=["documents", "metadatas"])
        chunks = []
        if res and res["documents"]:
            for doc, meta in zip(res["documents"], res["metadatas"]):
                chunks.append({
                    "text": doc,
                    "problem_number": meta.get("problem_number", -1),
                    "section": meta.get("section", ""),
                    "subsection": meta.get("subsection", ""),
                    "section_path": meta.get("section_path", ""),
                    "source": meta.get("source", ""),
                    "similarity": 1.0,
                    "match_type": "exact"
                })
        return chunks
    except Exception as e:
        print(f"  [!] Direct search error: {e}")
        return []


# ── جستجوی semantic با چند query ────────────────────────────
def search_semantic(queries: List[str], n: int = 12) -> List[Dict]:
    try:
        col = get_collection()
        if col.count() == 0:
            return []

        found: Dict[str, Dict] = {}

        for query in queries:
            if not query or not query.strip():
                continue
            emb = get_embeddings([query])[0]
            res = col.query(
                query_embeddings=[emb],
                n_results=min(n, col.count()),
                include=["documents", "metadatas", "distances"]
            )
            if not res["documents"][0]:
                continue

            for doc, meta, dist in zip(res["documents"][0], res["metadatas"][0], res["distances"][0]):
                sim = round(1 - dist, 3)
                key = f"{meta.get('source')}_{meta.get('chunk_index')}"
                if key not in found or found[key]["similarity"] < sim:
                    found[key] = {
                        "text": doc,
                        "problem_number": meta.get("problem_number", -1),
                        "section": meta.get("section", ""),
                        "subsection": meta.get("subsection", ""),
                        "section_path": meta.get("section_path", ""),
                        "source": meta.get("source", ""),
                        "similarity": sim,
                        "match_type": "semantic"
                    }

        return sorted(found.values(), key=lambda x: x["similarity"], reverse=True)
    except Exception as e:
        print(f"  [!] Semantic error: {e}")
        return []


# ── Reranking با GPT ─────────────────────────────────────────
def rerank(question: str, chunks: List[Dict]) -> List[Dict]:
    if len(chunks) <= 2:
        return chunks

    items = "\n".join([f"[{i+1}] {c['text'][:250]}" for i, c in enumerate(chunks[:10])])
    try:
        r = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": f"سوال: {question}\n\nهر متن را از 0 تا 10 بر اساس ارتباط با سوال امتیاز بده.\nفقط اعداد با کاما. مثال: 8,3,10,2,5"
                },
                {"role": "user", "content": items}
            ],
            temperature=0,
            max_tokens=60
        )
        scores_raw = r.choices[0].message.content.strip()
        scores = [float(s.strip()) for s in scores_raw.split(',') if s.strip()]
        for i, c in enumerate(chunks):
            c["rerank_score"] = scores[i] if i < len(scores) else 5.0
        return sorted(chunks, key=lambda x: x.get("rerank_score", 5), reverse=True)
    except:
        return chunks


# ── جستجوی کامل ─────────────────────────────────────────────
def full_search(original: str, normalized: str, analysis: Dict) -> List[Dict]:
    found: Dict[str, Dict] = {}

    # ۱. جستجوی مستقیم شماره مسئله
    prob_num = (
        extract_problem_number(original)
        or extract_problem_number(normalized)
    )
    if prob_num:
        print(f"  → Exact lookup: مسئله {prob_num}")
        for c in search_by_number(prob_num):
            found[f"exact_{prob_num}"] = c

    # ۲. ساخت queries متنوع
    expanded_original = expand_query(original)
    expanded_normalized = expand_query(normalized)

    queries = list(dict.fromkeys(filter(None, [
        original,
        normalized,
        expanded_original,
        expanded_normalized,
        analysis.get("formal_query", ""),
        analysis.get("keyword_query", ""),
        analysis.get("expanded_query", ""),
        " ".join(analysis.get("keywords_fa", [])),
        " ".join(analysis.get("keywords_ar", [])),
        analysis.get("section", "") + " " + analysis.get("keyword_query", ""),
    ])))

    # ۳. جستجوی semantic
    semantic = search_semantic(queries, n=12)
    for c in semantic:
        key = f"sem_{c['source']}_{c['problem_number']}_{c['text'][:15]}"
        if key not in found:
            found[key] = c

    if not found:
        return []

    chunks = list(found.values())

    # ۴. فیلتر
    filtered = [c for c in chunks if c["similarity"] >= SIMILARITY_THRESHOLD]
    if not filtered:
        # اگر هیچ چیز بالای threshold نبود، بهترین‌ها را بده
        filtered = sorted(chunks, key=lambda x: x["similarity"], reverse=True)[:5]

    # ۵. exact matches اول بیایند
    exact = [c for c in filtered if c.get("match_type") == "exact"]
    rest = [c for c in filtered if c.get("match_type") != "exact"]

    if exact:
        reranked_rest = rerank(original, rest[:8])[:4]
        return exact + reranked_rest

    return rerank(original, filtered[:12])[:8]


# ── System Prompt ────────────────────────────────────────────
SYSTEM_PROMPT = """تو دستیار تخصصی رساله فقهی آیت‌الله سید علی محمد دستغیب هستی.

## قوانین مطلق:
1. **فقط** از متن مسائل رساله استفاده کن - هرگز از دانش عمومی خود استفاده نکن
2. اگر جواب در مسائل بود → کامل توضیح بده و **شماره مسئله** را ذکر کن
3. اگر جواب نبود → بگو: «این مسئله در رساله موجود نیست.»
4. سوالات عامیانه فارسی را کاملاً درک کن و جواب فقهی رسمی بده
5. اگر چند مسئله مرتبط بود، همه را ذکر کن
6. جواب را با بخش‌بندی واضح بده:
   - **حکم:** ...
   - **توضیح:** ...
   - **مرجع:** مسئله [شماره] - [نام بخش]

## موضوع سوال: {topic}
## کلمات کلیدی: {keywords}

## مسائل رساله:
{context}"""


# ── پاسخ‌دهی اصلی ───────────────────────────────────────────
def answer_question(question: str) -> Dict:
    question = question.strip()

    # Small talk
    st = is_small_talk(question)
    if st:
        return {"answer": st, "sources": [], "found_in_docs": True, "keywords": []}

    # بررسی فایل
    stats = get_collection_stats()
    if stats.get("total_chunks", 0) == 0:
        return {
            "answer": "هنوز فایلی بارگذاری نشده. لطفاً ابتدا رساله را آپلود کنید.",
            "sources": [], "found_in_docs": False, "keywords": []
        }

    print(f"\n{'─'*50}")
    print(f"Q: {question}")

    # نرمال‌سازی عامیانه
    normalized = normalize_colloquial(question)
    if normalized != question:
        print(f"  Normalized: {normalized}")

    # تحلیل
    analysis = analyze_question(question, normalized)
    print(f"  Section: {analysis.get('section', '?')}")
    print(f"  Keywords: {analysis.get('keywords_fa', [])}")

    # جستجو
    chunks = full_search(question, normalized, analysis)
    print(f"  Results: {len(chunks)} chunks")

    if not chunks:
        # آخرین تلاش - جستجوی خیلی ساده
        chunks = search_semantic([question, normalized], n=5)
        chunks = [c for c in chunks if c["similarity"] >= 0.10]

    if not chunks:
        return {
            "answer": "این مسئله در رساله موجود نیست.\n\nپیشنهاد: سوال را با کلمات دیگری بپرسید یا موضوع کلی‌تری را جستجو کنید.",
            "sources": [], "found_in_docs": False,
            "keywords": analysis.get("keywords_fa", [])
        }

    # ساخت context
    context_parts = []
    for c in chunks:
        num = c["problem_number"]
        path = c.get("section_path", c.get("section", ""))
        sim = c["similarity"]
        if num > 0:
            context_parts.append(
                f"━━ مسئله {num} | {path} (امتیاز: {sim:.2f}) ━━\n{c['text']}"
            )
        else:
            context_parts.append(
                f"━━ توضیح | {path} (امتیاز: {sim:.2f}) ━━\n{c['text']}"
            )
    context = "\n\n".join(context_parts)

    kws_fa = analysis.get("keywords_fa", [])
    kws_ar = analysis.get("keywords_ar", [])
    all_kws = kws_fa + kws_ar

    try:
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": SYSTEM_PROMPT.format(
                        topic=analysis.get("section", ""),
                        keywords="، ".join(all_kws[:8]),
                        context=context
                    )
                },
                {"role": "user", "content": question}
            ],
            temperature=0.05,
            max_tokens=1500
        )

        answer = resp.choices[0].message.content
        not_found = any(p in answer for p in ["موجود نیست", "یافت نشد", "اطلاعاتی ندارم"])

        # ساخت sources با اطلاعات کامل
        sources = []
        seen = set()
        for c in chunks:
            num = c["problem_number"]
            key = f"{c['source']}_{num}"
            if key not in seen:
                seen.add(key)
                sources.append({
                    "filename": c["source"],
                    "page": num,
                    "similarity": c["similarity"],
                    "label": f"مسئله {num}" if num > 0 else "توضیح",
                    "section": c.get("section_path", c.get("section", ""))
                })

        return {
            "answer": answer,
            "sources": sources[:6],
            "found_in_docs": not not_found,
            "keywords": kws_fa[:6]
        }

    except Exception as e:
        return {
            "answer": f"خطا در پردازش: {str(e)}",
            "sources": [], "found_in_docs": False, "keywords": []
        }


# ── پاسخ‌دهی Streaming (برای main.py v3) ─────────────────────
async def answer_question_stream(
    question: str,
    cancel_event: asyncio.Event
) -> AsyncGenerator[Dict, None]:
    """پاسخ streaming - کلمه به کلمه با قابلیت cancel"""

    question = question.strip()

    # Small talk
    st = is_small_talk(question)
    if st:
        yield {"type": "answer", "content": st, "done": False}
        yield {"type": "done", "sources": [], "keywords": [], "found_in_docs": True}
        return

    # بررسی فایل
    stats = get_collection_stats()
    if stats.get("total_chunks", 0) == 0:
        yield {"type": "answer", "content": "هنوز فایلی بارگذاری نشده.", "done": False}
        yield {"type": "done", "sources": [], "keywords": [], "found_in_docs": False}
        return

    # نرمال‌سازی
    normalized = normalize_colloquial(question)

    yield {"type": "status", "content": "در حال تحلیل سوال..."}
    analysis = analyze_question(question, normalized)

    yield {"type": "status", "content": "در حال جستجو در رساله..."}
    if cancel_event.is_set():
        return

    chunks = full_search(question, normalized, analysis)
    if not chunks:
        chunks = search_semantic([question, normalized], n=5)
        chunks = [c for c in chunks if c["similarity"] >= 0.10]

    if not chunks:
        yield {"type": "answer", "content": "این مسئله در رساله موجود نیست.", "done": False}
        yield {"type": "done", "sources": [], "keywords": [], "found_in_docs": False}
        return

    # ساخت context
    context_parts = []
    for c in chunks:
        num = c["problem_number"]
        path = c.get("section_path", c.get("section", ""))
        sim = c["similarity"]
        header = f"مسئله {num} | {path}" if num > 0 else f"توضیح | {path}"
        context_parts.append(f"━━ {header} (امتیاز: {sim:.2f}) ━━\n{c['text']}")
    context = "\n\n".join(context_parts)

    kws_fa = analysis.get("keywords_fa", [])
    kws_ar = analysis.get("keywords_ar", [])
    all_kws = kws_fa + kws_ar

    system_prompt = SYSTEM_PROMPT.format(
        topic=analysis.get("section", ""),
        keywords="، ".join(all_kws[:8]),
        context=context
    )

    yield {"type": "status", "content": "در حال تولید پاسخ..."}
    if cancel_event.is_set():
        return

    full_answer = ""
    try:
        stream = await async_client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            temperature=0.05,
            max_tokens=1500,
            stream=True
        )

        async for chunk in stream:
            if cancel_event.is_set():
                await stream.close()
                return
            if chunk.choices and chunk.choices[0].delta.content:
                token = chunk.choices[0].delta.content
                full_answer += token
                yield {"type": "answer", "content": token, "done": False}
                await asyncio.sleep(0)

        # ساخت sources
        sources = []
        seen = set()
        for c in chunks:
            num = c["problem_number"]
            key = f"{c['source']}_{num}"
            if key not in seen:
                seen.add(key)
                sources.append({
                    "filename": c["source"],
                    "page": num,
                    "similarity": c["similarity"],
                    "label": f"مسئله {num}" if num > 0 else "توضیح",
                    "section": c.get("section_path", c.get("section", ""))
                })

        not_found = any(p in full_answer for p in ["موجود نیست", "یافت نشد"])
        yield {
            "type": "done",
            "sources": sources[:6],
            "keywords": kws_fa[:5],
            "found_in_docs": not not_found
        }

    except Exception as e:
        yield {"type": "error", "content": f"خطا: {str(e)}"}
